# Cloudify Diamond Plugin

* Master [![Circle CI](https://circleci.com/gh/cloudify-cosmo/cloudify-diamond-plugin/tree/master.svg?style=shield)](https://circleci.com/gh/cloudify-cosmo/cloudify-diamond-plugin/tree/master)
* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-diamond-plugin.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-diamond-plugin) [![Circle CI](https://circleci.com/gh/cloudify-cosmo/cloudify-diamond-plugin/tree/master.svg?&style=shield)](https://circleci.com/gh/cloudify-cosmo/cloudify-diamond-plugin/tree/master)
* PyPI [![PyPI](http://img.shields.io/pypi/dm/cloudify-diamond-plugin.svg)](http://img.shields.io/pypi/dm/cloudify-diamond-plugin.svg)
* Version [![PypI](http://img.shields.io/pypi/v/cloudify-diamond-plugin.svg)](http://img.shields.io/pypi/v/cloudify-diamond-plugin.svg)

Cloudify [Diamond](https://github.com/BrightcoveOS/Diamond) monitoring plugin.

See [Diamond Plugin](http://docs.getcloudify.org/latest/plugins/diamond)

