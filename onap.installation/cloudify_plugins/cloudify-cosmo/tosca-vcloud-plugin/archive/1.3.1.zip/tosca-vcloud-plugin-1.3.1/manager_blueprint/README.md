Manager blueprint moved to https://github.com/cloudify-cosmo/cloudify-manager-blueprints/

Please use as manager blueprint such file: vcloud-manager-blueprint.yaml

Inputs example here: vcloud-manager-blueprint-inputs.yaml
