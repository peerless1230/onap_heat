import module_that_does_not_exist  # noqa
