#!/bin/bash

ctx instance runtime-properties "test" "Say hello to my little friend!"
