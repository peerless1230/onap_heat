# Cloudify Manager Blueprints

* Master [![Circle CI](https://circleci.com/gh/cloudify-cosmo/cloudify-manager-blueprints/tree/master.svg?style=shield)](https://circleci.com/gh/cloudify-cosmo/cloudify-manager-blueprints/tree/master)

This repository contains blueprints for bootstrapping Cloudify

## Usage

See [Bootstrapping Cloudify](http://getcloudify.org/guide/installation-bootstrapping.html)
